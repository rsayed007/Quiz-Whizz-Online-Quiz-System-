<?php 
	include 'inc/header.php';
	include 'lib/class.php';

$logout = new user;
$logout->logouot();

?>